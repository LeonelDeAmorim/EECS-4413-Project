package application.DTO;

import java.time.LocalDateTime;

public class DealDTORequest {

	private long id;
	private double rate;
	private LocalDateTime date;
	
	public DealDTORequest() {
		
	}
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public double getRate() {
		return rate;
	}
	public void setRate(double rate) {
		this.rate = rate;
	}
	public LocalDateTime getDate() {
		return date;
	}
	public void setDate(LocalDateTime date) {
		this.date = date;
	}
}
