package application.DTO;

import java.time.LocalDateTime;

import application.model.Item;
import application.model.Review;

public class ReviewDTO {

	private Review review;
	private String ItemDetails;

	public ReviewDTO() {

	}

	public ReviewDTO(Review review, String item_info) {
		this.review = review;

		this.ItemDetails = item_info;

	}

	public Review getReview() {
		return review;
	}

	public void setReview(Review review) {
		this.review = review;
	}

	public String getItemDetails() {
		return ItemDetails;
	}

	public void setItemDetails(String itemDetails) {
		ItemDetails = itemDetails;
	}

}
