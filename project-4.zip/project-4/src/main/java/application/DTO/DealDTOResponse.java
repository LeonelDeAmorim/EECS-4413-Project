package application.DTO;

import java.time.LocalDateTime;

import application.model.Item;

public class DealDTOResponse {
	private Item item;
	private double old_price;
	private double rate;
	private LocalDateTime endDate;

	public DealDTOResponse() {

	}

	public DealDTOResponse(Item item, double old_price, double rate, LocalDateTime end) {
		this.item=item;
		this.old_price=old_price;
		this.rate=rate;
		this.endDate=end;
	}

	public Item getItem() {
		return item;
	}

	public void setItem(Item item) {
		this.item = item;
	}

	public double getOld_price() {
		return old_price;
	}

	public void setOld_price(double old_price) {
		this.old_price = old_price;
	}

	public double getRate() {
		return rate;
	}

	public void setRate(double rate) {
		this.rate = rate;
	}

	public LocalDateTime getEndDate() {
		return endDate;
	}

	public void setEndDate(LocalDateTime endDate) {
		this.endDate = endDate;
	}
}
