package application.DTO;

import java.util.List;

public class ReviewDTOResponse {

	private List<ReviewDTO> dto;
	private double score;

	public ReviewDTOResponse() {

	}

	public ReviewDTOResponse(List<ReviewDTO> dto, double rating) {
		this.score = rating;
		this.dto = dto;
	}

	public List<ReviewDTO> getDto() {
		return dto;
	}

	public void setDto(List<ReviewDTO> dto) {
		this.dto = dto;
	}

	public double getScore() {
		return score;
	}

	public void setScore(double score) {
		this.score = score;
	}

}
