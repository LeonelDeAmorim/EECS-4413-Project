package application.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import application.model.Item;
import application.model.ItemDeal;

@Repository
public interface ItemDealRepository extends  JpaRepository<ItemDeal, Long> {

}
