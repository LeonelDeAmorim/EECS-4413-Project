package application.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import application.DTO.ItemDTO;
import application.exception.TransactionNotFoundException;
import application.model.Item;
import application.model.Transaction;
import application.repository.TransactionRepository;
import application.service.TransactionService;

@RestController
@CrossOrigin(origins = "http://localhost:3000")

public class TransactionController {

	@Autowired
	private TransactionService service;

	@GetMapping("/transaction")
	List<Transaction> all() {
		return service.getAll();
	}

	@PostMapping("/transaction")
	Transaction newTransaction(@RequestBody Transaction transaction) {
		return service.post(transaction);
	}

	// , @RequestParam(required = false) Long user_id	

	@GetMapping("/transaction/{id}")
	Transaction one(@PathVariable Long id) {
		return service.getOne(id);
	}

	@DeleteMapping("/transaction/{id}")
	void deleteTransaction(@PathVariable Long id) {
		service.delete(id);
	}

	@PutMapping("/transaction/{id}")
	Transaction replaceTransaction(@RequestBody Transaction newTransaction, @PathVariable Long id) {

		return service.replace(newTransaction, id);

	}
}