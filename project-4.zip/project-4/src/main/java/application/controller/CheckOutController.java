package application.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import application.DTO.ItemDTO;
import application.DTO.ReceiptDTO;
import application.service.CheckOutFacade;

@RestController
@CrossOrigin(origins = "http://localhost:3000")

public class CheckOutController {

	@Autowired
	private CheckOutFacade service;

    @PostMapping("/checkout")
    ReceiptDTO Checkout(@RequestBody List<ItemDTO> items, @RequestParam(required = false) Long user_id){
    	return service.checkout(items,user_id);
    }
    
    @GetMapping("/receipt")
   List <ReceiptDTO> getAll() {
    	return service.getAll();
    }
    
    @GetMapping("/receipt/{id}")
    ReceiptDTO getReceipt(@PathVariable long id) {
    	return service.getOne(id);
    }
    
    @GetMapping("/userReceipts/{id}")  
    List<ReceiptDTO> getUserReceipt(@PathVariable long id) {
    	return service.getUserTransactions(id);
    }
}
