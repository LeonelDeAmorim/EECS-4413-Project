package application.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import application.exception.OrderNotFoundException;
import application.model.Order;
import application.repository.OrderRepository;
import application.service.OrderService;

@RestController
@CrossOrigin(origins = "http://localhost:3000")

public class OrderController {

	@Autowired
	private OrderService service;

	@GetMapping("/order")
	List<Order> all() {
		return service.getAll();
	}

	@PostMapping("/order")
	Order newOrder(@RequestBody Order newOrder) {
		return service.post(newOrder);
	}

	@GetMapping("/order/{id}")
	Order one(@PathVariable Long id) {
		return service.findOne(id);
	}

	@DeleteMapping("/order/{id}")
	void deleteOrder(@PathVariable Long id) {
		service.delete(id);
	}

	@PutMapping("/order/{id}")
	Order replaceOrder(@RequestBody Order newOrder, @PathVariable Long id) {
		return service.replace(newOrder, id);
	}
}
