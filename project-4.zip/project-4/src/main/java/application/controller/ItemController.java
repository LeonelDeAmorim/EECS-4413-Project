package application.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import application.exception.ItemNotFoundException;
import application.model.Item;
import application.repository.ItemRepository;
import application.service.ItemService;

//changed from restcontroller to display functionality will change when frontend developed
//@Controller
@RestController
@CrossOrigin(origins = "http://localhost:3000")

public class ItemController {

	@Autowired
	private ItemService service;

	
//	@GetMapping("/items")
//	public String showItems(Model model) {
//		List<Item> availableCars = service.getAll();
//		model.addAttribute("cars", availableCars);
//		return "items";
//	}
	
	@GetMapping("/items")
	public List<Item> getItems(){
		return service.getAll();
		}

	@PostMapping("/items")
	Item newItem(@RequestBody Item newItem) {
		return service.post(newItem);
	}
	
	@PostMapping("/items/all")
	List<Item> bulkPost(@RequestBody List<Item> newItem){
		return service.postAll(newItem);
	}

	@GetMapping("/items/{id}")
	Item oneItem(@PathVariable Long id) {
		return service.getItem(id);
	}

	@PutMapping("/items/{id}")
	Item replaceItem(@RequestBody Item newItem, @PathVariable Long id) {
		return service.replace(newItem,id);

	}
	
	@PutMapping("/itemIncrease/{id}")
	Item updateQuantityByTem(@PathVariable Long id) {
		return service.increaseByTen(id);

	}

	@DeleteMapping("/items/{id}")
	void deleteItem(@PathVariable Long id) {
		service.delete(id);
	}

}
