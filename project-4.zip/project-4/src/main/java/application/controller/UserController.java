package application.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import application.DTO.LoginResponseDTO;
import application.exception.UserNotFoundException;
import application.model.User;
import application.repository.UserRepository;
import application.service.UserService;

@RestController
@CrossOrigin(origins = "http://localhost:3000")

public class UserController {
 
	@Autowired
	private UserService service;

	

	@GetMapping("/users")
	List<User> all() {
		return service.getAll();
	}

	@PostMapping("/users")
	@Transactional

	ResponseEntity<String> newUser(@RequestBody User newUser) {
		if(service.save(newUser))
			return new ResponseEntity<String>(HttpStatus.CREATED);
		return new ResponseEntity<String>(HttpStatus.BAD_REQUEST);
	}

	@GetMapping("/users/{id}")
	User getUser(@PathVariable Long id) {
		return service.getUser(id);
		}

	@PostMapping("/login")
	LoginResponseDTO login(@RequestBody User user) {
		return service.validate(user);
	}

	@PutMapping("/users/{id}")
	User updatePassword(@RequestBody User user) {
		return service.updatePassword(user);
	}

	@DeleteMapping("/users/{id}")
	void deleteEmployee(@PathVariable Long id) {
		service.deleteUser(id);
	}

}