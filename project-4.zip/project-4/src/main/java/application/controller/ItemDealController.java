package application.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import application.DTO.DealDTORequest;
import application.DTO.DealDTOResponse;
import application.model.ItemDeal;
import application.service.ItemDealService;

@RestController
@CrossOrigin(origins = "http://localhost:3000")

public class ItemDealController {

	@Autowired
	private ItemDealService service;
	
	@GetMapping("/deals")
	List<DealDTOResponse> getAll(){
		return service.getAll();
	}
	
	@PostMapping("/deals")
	DealDTOResponse post(@RequestBody DealDTORequest dealInfo) {
		return service.post(dealInfo);
	}
}
