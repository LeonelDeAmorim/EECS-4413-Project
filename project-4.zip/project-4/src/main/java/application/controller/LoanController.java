package application.controller;


import application.service.LoanCalculator;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

//changed from restcontroller to display functionality will change when frontend developed
@RestController
@CrossOrigin(origins = "http://localhost:3000")

public class LoanController {
	@Autowired
    private LoanCalculator loanCalculator;

    
    @GetMapping("/loanCalculator")
    public String loanCalculatorPage() {
        return "loanCalculator";
    }

    @RequestMapping("/calculateLoan")
    public double calculateLoan(@RequestParam("vehiclePrice") double vehiclePrice,
                                @RequestParam("downPayment") double downPayment,
                                @RequestParam("interestRate") double interestRate,
                                @RequestParam("duration") int duration) {

        double monthlyPayment = loanCalculator.CalculateLoan(vehiclePrice, downPayment, interestRate, duration);
        
        
        
        return monthlyPayment;
    }
}
