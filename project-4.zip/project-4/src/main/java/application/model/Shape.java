package application.model;

public enum Shape {
SUV,SEDAN,PICKUP,MINIVAN,SPORTS,OTHER
}
