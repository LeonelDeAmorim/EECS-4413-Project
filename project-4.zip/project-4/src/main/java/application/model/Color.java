package application.model;

public enum Color {
RED,GREEN,BLACK,BLUE,YELLOW,WHITE,GREY
}
