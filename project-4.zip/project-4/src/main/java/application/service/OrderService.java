package application.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import application.exception.OrderNotFoundException;
import application.model.Order;
import application.repository.OrderRepository;

@Service
public class OrderService {

	@Autowired
	private OrderRepository repository;

	public List<Order> getAll() {
		return repository.findAll();
	}
	
	public List<Order> itemOrders(long user_id ) {
		List<Order> orders = new ArrayList<>();
		for(Order order: getAll()) {
			if(order.getItem_id()==user_id)
				orders.add(order);
		}
		
		return orders;
	}

	public Order post(Order order) {
		return repository.save(order);
	}

	public Order findOne(long id) {
		return repository.findById(id).orElseThrow(() -> new OrderNotFoundException(id));
	}

	public void delete(long id) {
		repository.deleteById(id);
	}

	public Order replace(Order newOrder, Long id) {
		return repository.findById(id).map(order -> {
			order.setItem_id(newOrder.getItem_id());
			order.setPrice(newOrder.getPrice());
			order.setQuantity(newOrder.getQuantity());
			order.setSubtotal(newOrder.getQuantity());
			order.setTransaction_id(newOrder.getTransaction_id());
			return repository.save(order);
		}).orElseGet(() -> {
			return repository.save(newOrder);
		});
	}

	public List<Order> getByTransaction(long id) {
		List<Order> orders = new ArrayList<Order>();
		for (Order order : this.getAll()) {
			if (order.getTransaction_id() == id)
				orders.add(order);
		}
		return orders;
	}

}
