package application.service;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import application.DTO.ItemDTO;
import application.DTO.ReceiptDTO;
import application.model.Order;
import application.model.Transaction;

@Service
public class CheckOutFacade {

	@Autowired
	private TransactionService transactionService;
	@Autowired
	private ItemService itemService;
	@Autowired
	private UserService userService;
	@Autowired
	private OrderService orderService;

//	@Transactional(rollbackFor = Exception.class)
	public ReceiptDTO checkout(List<ItemDTO> items, Long user_id) {
		List<Order> orders = new ArrayList<Order>();

		Transaction transaction = new Transaction();
		transaction.setOrder_date(LocalDateTime.now());
		transaction.setTotal(itemService.getTotal(items));
		if (userService.authenticate(user_id))
			transaction.setUser_id(user_id);
//		System.out.println("before saving transaction");
		// transaction posted
		try {
			transactionService.post(transaction);
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
//		System.out.println("After");
		// post orders
		for (ItemDTO item : items)
			orders.add(
					orderService.post(new Order(transaction.getId(), item.getId(), itemService.getPrice(item.getId()),
							(itemService.getPrice(item.getId()) * item.getQuantity()), item.getQuantity())));

//		// item table update
		itemService.updateStocks(items);

		return new ReceiptDTO(transaction.getId(), transaction.getTotal(), orders, transaction.getOrder_date());
	}

	public ReceiptDTO getOne(long id) {
		Transaction t = transactionService.getOne(id);
		return new ReceiptDTO(id, t.getTotal(), orderService.getByTransaction(id), t.getOrder_date());
	}

	public List<ReceiptDTO> getAll() {
		List<ReceiptDTO> receipts = new ArrayList<ReceiptDTO>();
		for (Transaction t : transactionService.getAll()) {
			receipts.add(getOne(t.getId()));
		}
		return receipts;
	}
	
	public List<ReceiptDTO> getUserTransactions(long user_id) {
		List<ReceiptDTO> receipts = new ArrayList<ReceiptDTO>();
		for(Transaction t: transactionService.userTransactions(user_id)) {
			receipts.add(getOne(t.getId()));
		}
		
		return receipts;
	}

}
