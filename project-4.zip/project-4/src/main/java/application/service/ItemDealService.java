package application.service;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import application.DTO.DealDTORequest;
import application.DTO.DealDTOResponse;
import application.model.Item;
import application.model.ItemDeal;
import application.repository.ItemDealRepository;
import application.repository.ItemRepository;

@Service
public class ItemDealService {

	@Autowired
	private ItemDealRepository dealRepository;
	@Autowired
	private ItemRepository itemRepository;

	public List<DealDTOResponse> getAll() {
		List<DealDTOResponse> deals = new ArrayList<DealDTOResponse>();

		for (ItemDeal deal : dealRepository.findAll()) {
			
			if (deal.getEndDate().isAfter(LocalDateTime.now())) {
				deals.add(new DealDTOResponse(
					itemRepository.findById(deal.getId()).get(),deal.getOldPrice(),deal.getDiscountRate(),deal.getEndDate()
						));
			}
//				deals.add(deal);
		}
		return deals;
	}
	

	public DealDTOResponse post(DealDTORequest info) {
		System.out.println("info id:"+info.getId()+" date:"+info.getDate()+" rate: " + info.getRate());
		
		Long id = info.getId();
		double rate = info.getRate();
		LocalDateTime time = info.getDate();

		Item item = itemRepository.findById(id).get();
		double old_price = item.getPrice();
		double new_price = Math.round((item.getPrice() * (1 - rate)));
		item.setPrice(new_price);
		itemRepository.save(item);

		ItemDeal deal = new ItemDeal();
		deal.setId(item.getId());
		deal.setEndDate(time);
		deal.setNewPrice(new_price);
		deal.setOldPrice(old_price);
		deal.setDiscountRate(rate);
		dealRepository.save(deal);

		return new DealDTOResponse(item, old_price, rate, time);

	}

}
