package application.service;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import application.DTO.ItemDTO;
import application.exception.ItemExceedingStockException;
import application.exception.ItemNotFoundException;
import application.exception.TransactionNotFoundException;
import application.model.Item;
import application.model.Order;
import application.model.Transaction;
import application.repository.ItemRepository;
import application.repository.OrderRepository;
import application.repository.TransactionRepository;

@Service
public class TransactionService {

	@Autowired
	private TransactionRepository repository;

	public List<Transaction> getAll() {
		return repository.findAll();
	}

	@Transactional
	public Transaction post(Transaction transction) {
		return repository.save(transction);
	}

	public Transaction getOne(Long id) {
		return repository.findById(id).orElseThrow(() -> new TransactionNotFoundException(id));
	}
	
	public void delete(Long id) {
		repository.deleteById(id);
	}

	public Transaction replace(Transaction transaction, Long id) {
		Transaction t = repository.findById(id).orElseThrow(() -> new TransactionNotFoundException(id));
		t.setOrder_date(transaction.getOrder_date());
		t.setTotal(transaction.getTotal());
		t.setUser_id(transaction.getUser_id());	
		return repository.save(t);
	}
	
	public List<Transaction>userTransactions(Long id) {
		List<Transaction> t= new ArrayList<>();
		
		for(Transaction transaction :this.getAll()) {
			if(transaction.getUser_id()==id)
				t.add(transaction);
		}
		return t;
	}

}