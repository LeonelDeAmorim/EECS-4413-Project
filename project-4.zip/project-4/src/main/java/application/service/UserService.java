package application.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import application.DTO.LoginResponseDTO;
import application.exception.UserNotFoundException;
import application.model.User;
import application.repository.UserRepository;

@Service
public class UserService {

	@Autowired
	private UserRepository repository;
	
	public boolean exists(String username) {
		for(User user :getAll()) {
			if(user.getUsername().toLowerCase().equals(username))
					return true;
		}
		return false;
	}
	
	public LoginResponseDTO validate(User user) {
		return new LoginResponseDTO(user.getUsername(),authenticate(user));
	}
	
	public Long authenticate(User user) {
		for (User entry : repository.findAll()) {
			if (entry.getUsername().toLowerCase().equals(user.getUsername().toLowerCase())
					&& entry.getPassword().equals(user.getPassword())) {
				return entry.getId();
			}
		}
		return null;
	}
	
	public boolean authenticate(Long id) {
		if(id != null)
			return getUser(id).getId()==id;
		return false;
	}

	public List<User> getAll() {
		return repository.findAll();
	}

	public boolean save(User newUser) {
		if(!exists(newUser.getUsername())) {
		 repository.save(newUser);
		return true;
		}
		return false;	
	}

	public User getUser(Long id) {
		return repository.findById(id).orElseThrow(() -> new UserNotFoundException(id));

	}

	public void deleteUser(Long id) {
		repository.deleteById(id);

	}

	public User updatePassword(User user) {
		for (User entry : repository.findAll()) {
			if (entry.getUsername().toLowerCase().equals(user.getUsername().toLowerCase())) {
				entry.setPassword(user.getPassword());
				return repository.save(entry);
			}
		}
		return null;
	}
}
