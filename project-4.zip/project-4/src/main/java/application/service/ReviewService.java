package application.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import application.DTO.ReviewDTO;
import application.DTO.ReviewDTOResponse;
import application.model.Item;
import application.model.Order;
import application.model.Review;
import application.model.Transaction;
import application.repository.ItemRepository;
import application.repository.ReviewRepository;

@Service
public class ReviewService {

	@Autowired
	private ReviewRepository repository;
	@Autowired
	private ItemService itemService;
	@Autowired
	private UserService userService;
	@Autowired
	private OrderService orderService;
	@Autowired
	private TransactionService transactionService;

	public double newReview(Review newReview) {
		boolean flag = false;
		try {
			if (userService.authenticate(newReview.getUser_id())) {
				List<Transaction> transactions = transactionService.userTransactions(newReview.getUser_id());
				
				for(Order order : orderService.itemOrders(newReview.getItem_id())) {
					for(Transaction t : transactions)
						if(order.getTransaction_id()==t.getId()) {
							flag = true;
							System.out.println("Matched transaction:"+t.getId()+ "  order"+order.getTransaction_id());
							break;
						}
				}
			}
			if(flag) {
				Review saved = repository.save(newReview);
				return itemReviews(newReview.getItem_id()).getScore();
			}

		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
		return -1;
	}

	public ResponseEntity<Review> singleReview(long id) {
		return repository.findById(id).map(review -> new ResponseEntity<>(review, HttpStatus.OK))
				.orElseGet(() -> new ResponseEntity<Review>(HttpStatus.NOT_FOUND));
	}

	public double calculate(List<ReviewDTO> dto) {
		int counter = 0;
		double total = 0;

		for (ReviewDTO review : dto) {
			total += review.getReview().getRating();
			if (review.getReview().getRating() > 0)
				counter++;
		}
		System.out.println("Total:"+total+" counter:"+counter);
		if (counter != 0)
			return (double) total / counter;
		return -1;
	}

	public ReviewDTOResponse itemReviews(long id) {
		List<ReviewDTO> dto = new ArrayList<>();
		repository.findAll().forEach(review -> {

			if (review.getItem_id() == id) {
				Item item = itemService.getItem(id);
				dto.add(new ReviewDTO(review,
						(item.getYear() + " " + item.getBrand() + " " + item.getColor() + " " + item.getShape())));
			}
		});
		return new ReviewDTOResponse(dto, calculate(dto));
	}

	public ReviewDTOResponse userReview(long id) {
		List<ReviewDTO> dto = new ArrayList<>();

		repository.findAll().forEach(review -> {
			if (review.getUser_id() == id) {
				Item item = itemService.getItem(review.getItem_id());
				dto.add(new ReviewDTO(review,
						(item.getYear() + " " + item.getBrand() + " " + item.getColor() + " " + item.getShape())));
			}
		});
		return new ReviewDTOResponse(dto, calculate(dto));
	}

	public ResponseEntity<Review> updateReview(Review newReview, long id) {
		return repository.findById(id).map(review -> {
			review.setComment(newReview.getComment());
			review.setCreated(newReview.getCreated());
			review.setRating(newReview.getRating());
			Review updatedReview = repository.save(review);
			return new ResponseEntity<Review>(updatedReview, HttpStatus.OK);
		}).orElseGet(() -> {
			return new ResponseEntity<Review>(HttpStatus.NOT_FOUND);
		});
	}

	public List<Review> getAll() {
		return repository.findAll();
	}

	public void delete(Long id) {
		repository.deleteById(id);

	}
}
