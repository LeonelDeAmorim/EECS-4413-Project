package application.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import application.DTO.ItemDTO;
import application.exception.ItemExceedingStockException;
import application.exception.ItemNotFoundException;
import application.model.Item;
import application.model.Order;
import application.repository.ItemRepository;

@Service
public class ItemService {

	@Autowired
	private ItemRepository repository;

	public void updateStocks(List<ItemDTO> dto) {
		for (ItemDTO item : dto)
			updateStock(item);
	}

	public double getPrice(long id) {
		return repository.findById(id).get().getPrice();
	}
	
	@Transactional
	public void updateStock(ItemDTO itemDTO) {
		repository.findById(itemDTO.getId()).map(i -> {
			i.setQuantity(i.getQuantity() - itemDTO.getQuantity());
			if (i.getQuantity() < 0)
				throw new ItemExceedingStockException("Order for" + i.getYear() + " " + i.getBrand() + " "
						+ i.getShape() + " exceeds the available quantity");
			return repository.save(i);
		}).orElseThrow(() -> new ItemNotFoundException(itemDTO.getId()));

	}

	public List<Item> getAll() {
		return repository.findAll();
	}

	public Item post(Item newItem) {
		return repository.save(newItem);
	}

	public Item getItem(Long id) {
		return repository.findById(id).orElseThrow(() -> new ItemNotFoundException(id));
	}

	public void delete(Long id) {
		repository.deleteById(id);

	}

	public Item replace(Item newItem, Long id) {
		return repository.findById(id).map(item -> {
			item.setBrand(newItem.getBrand());
			item.setColor(newItem.getColor());
			item.setCondition(newItem.getCondition());
			item.setMileage(newItem.getMileage());
			item.setPrice(newItem.getPrice());
			item.setQuantity(newItem.getQuantity());
			item.setShape(newItem.getShape());
			item.setYear(newItem.getYear());
			return repository.save(item);
		}).orElseGet(() -> {
			return repository.save(newItem);
		});
	}

	public double getTotal(List<ItemDTO> items) {
		double total = 0;

		for (ItemDTO item : items)
			total += repository.findById(item.getId()).get().getPrice() * item.getQuantity();

		return total;
	}

	public Item increaseByTen(Long id) {
		Item item = getItem(id);
		item.setQuantity(item.getQuantity()+10);
		return repository.save(item);
	}
	

	public List<Item> postAll(List<Item> newItem) {
			List<Item> items = new ArrayList<>();
			for(Item item: newItem)
				items.add(repository.save(item));
			
			
			return items;
	}

}
