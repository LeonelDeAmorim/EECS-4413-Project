import React, { useState } from 'react';
import axios from 'axios';
import { BrowserRouter as Router, Route, Routes, Link } from 'react-router-dom';
import { Container, Button, AppBar, Toolbar, Typography, Box, Grid, Card, CardContent, TextField } from '@mui/material';  // Add TextField import here
import ReviewButton from './components/ReviewButton';
import AllReviews from './components/AllReviews';
import Login from './components/Login';
import Home from './components/Home';
import HotDeals from './components/HotDeals';
import Cookies from "js-cookie";
import ItemDetail from './components/ItemDetail'
import SignUp from './components/SignUp';
import Cart from './components/Cart';
import PersonOutlineIcon from '@mui/icons-material/PersonOutline';
import HomeIcon from '@mui/icons-material/Home';
import BrandShowcase from './components/BrandsShowcase';
import logo from './Logo/logo-transparent.png';


// LoanCalculator Component
const LoanCalculator = () => {
  const [vehiclePrice, setVehiclePrice] = useState(0);
  const [downPayment, setDownPayment] = useState(0);
  const [interestRate, setInterestRate] = useState(0);
  const [duration, setDuration] = useState(0);
  const [monthlyPayment, setMonthlyPayment] = useState(0);

  const handleSubmit = async (e) => {
    e.preventDefault();

    try {
      const response = await axios.get("http://localhost:5000/calculateLoan", {
        params: {
          vehiclePrice,
          downPayment,
          interestRate,
          duration,
        },
      });

      setMonthlyPayment(response.data);
      console.log(response.data)
    } catch (error) {
      console.error("Error fetching loan details:", error);
    }
  };

  return (
    <Container maxWidth="sm" sx={{ padding: 3 }}>
    <Typography variant="h4" gutterBottom align="center" sx={{ fontWeight: 600 }}>
      Loan Calculator
    </Typography>
  
    <form onSubmit={handleSubmit}>
      <Grid container spacing={3}>
        <Grid item xs={12} sm={6}>
          <TextField
            label="Vehicle Price($)"
            type="number"
            fullWidth
            value={vehiclePrice}
            onChange={(e) => setVehiclePrice(e.target.value)}
            required
            sx={{ '& .MuiInputBase-root': { fontSize: '1.1rem' } }}
          />
        </Grid>
        <Grid item xs={12} sm={6}>
          <TextField
            label="Down Payment($)"
            type="number"
            fullWidth
            value={downPayment}
            onChange={(e) => setDownPayment(e.target.value)}
            required
            sx={{ '& .MuiInputBase-root': { fontSize: '1.1rem' } }}
          />
        </Grid>
        <Grid item xs={12} sm={6}>
          <TextField
            label="Interest Rate (%)"
            type="number"
            fullWidth
            value={interestRate}
            onChange={(e) => setInterestRate(e.target.value)}
            required
            sx={{ '& .MuiInputBase-root': { fontSize: '1.1rem' } }}
          />
        </Grid>
        <Grid item xs={12} sm={6}>
          <TextField
            label="Duration (Months)"
            type="number"
            fullWidth
            value={duration}
            onChange={(e) => setDuration(e.target.value)}
            required
            sx={{ '& .MuiInputBase-root': { fontSize: '1.1rem' } }}
          />
        </Grid>
      </Grid>
      <Button
        variant="contained"
        color="primary"
        type="submit"
        sx={{
          marginTop: 3,
          width: '90%',
          fontSize: '1rem',
          padding: '10px 0',
          
          '&:hover': {
            backgroundColor: '#1565c0',
            transform: 'scale(1.05)',
          },
        }}
      >
        Calculate Loan
      </Button>
    </form>
  
    {monthlyPayment !== null && (
      <Box sx={{ marginTop: 3, textAlign: 'center' }}>
        <Typography variant="h6" sx={{ fontWeight: 600 }}>
          Your Monthly Payment would be: ${monthlyPayment}
        </Typography>
      </Box>
    )}
  </Container>
  );
};

// ItemList Component (Modified to include Add to Cart functionality)


const ItemList = ({ addToCart }) => {
  const [items, setItems] = useState([]);

  React.useEffect(() => {
    axios.get("http://localhost:5000/items")
      .then(response => {
        setItems(response.data);
      })
      .catch(error => {
        console.error("Error fetching items:", error);
      });
  }, []);

  // Filter and Sorting Logic
  const [filters, setFilters] = useState({
    minPrice: 0,
    maxPrice: 1000000,
    brand: '',
  });
  const [sortOption, setSortOption] = useState('');

  const handleFilterChange = (event) => {
    const { name, value } = event.target;
    setFilters({
      ...filters,
      [name]: value,
    });
  };

  const handleSortChange = (event) => {
    setSortOption(event.target.value);
  };

  const filteredItems = items.filter(item =>
    item.price >= filters.minPrice && item.price <= filters.maxPrice &&
    (filters.brand ? item.brand.toLowerCase().includes(filters.brand.toLowerCase()) : true)
  );

  const sortedItems = filteredItems.sort((a, b) => {
    if (sortOption === 'priceLowToHigh') {
      return a.price - b.price;
    } else if (sortOption === 'priceHighToLow') {
      return b.price - a.price;
    }
    else if(sortOption==='MileageLowToHigh'){
      return a.mileage - b.mileage;
    }
    else if(sortOption==='MileageHighToLow'){
      return b.mileage - a.mileage; 
    }
    else if(sortOption==='YearHighToLow'){
      return b.year - a.year; 
    }
    else if(sortOption==='YearLowToHigh'){
      return a.year - b.year; 
    }

    return 0;
  });

  const subaruImageUrl = "https://file.kelleybluebookimages.com/kbb/base/evox/CP/10961/2017-Subaru-Forester-front_10961_032_1848x898_J8U_cropped.png";
  const nissanImageUrl = "https://file.kelleybluebookimages.com/kbb/base/evox/CP/13188/2020-Nissan-Frontier%20Crew%20Cab-front_13188_032_1878x829_KAD_cropped.png";
  const mercedesBenzImageUrl = "https://di-shared-assets.dealerinspire.com/legacy/rackspace/ldm-images/2020-mercedes-benz-c-class-AMG-C-43-4MATIC-Sedan-ca.png";
  const rivianImageUrl = "https://cdcssl.ibsrv.net/autodata/images/?img=USD30RIS011B022008.jpg&width=700";
  const hondaImageUrl = "https://di-shared-assets.dealerinspire.com/legacy/rackspace/ldm-images/2019-honda-accord-crystal-black-pearl.png";
  const toyotaImageUrl = "https://global.toyota/pages/news/images/2020/06/08/1330/001.jpg";
  const jeepImageUrl = "https://dbhdyzvm8lm25.cloudfront.net/stills_0640_png/MY2020/13881/13881_st0640_116.png";  // JEEP image URL
  const bmwImageUrl = "https://prod.cosy.bmw.cloud/bmwweb/cosySec?COSY-EU-100-2545xM4RIyFnbm9Mb3AgyyIJrjG0suyJRBODlsrjGpuaprQbhSIqppglBgbFnvl384MlficYiGHqoQxYLW7%25f3tiJ0PCJirQbLDWcQW7%251u2aIqoQh47wMvcYi967wVMb3islBglUtI6cRScH7o3MbnMdemRyJGy5mgprQ%25r98BYW8zWuo86qogqa3s7l3ilUbv9cRScHJaQMbnMdoi0yJGy53ORrQ%25r9R1GW8zWubxdqogqaJh%25l3ilUQTUcRScH753MbnMd08KyJGy5BOorQ%25r9Yp9W8zWunUGqogqaGjdl3ilU%257QcRScHz0oMbnMdgmKyJGy5i0SrQ%25r9SDFW8zWunC%25qogqaGrEl3ilU%25vzcRScHzRUMbnMdgCEyJGy5mYnrQ%25r9snGW8zWuKGEqogqaDJ%25l3ilUCQ6cRScH48WMbnMdeoLyJGy5mgSrQ%25r9sicW8zWuoGCqogqa3C4l3ilURQzcRScHb8UMbnMdJozyJGy5QinrQ%25r982bW8zWuoxdqogqaaRdl3ilUUHecRScHHwUMbnMdj3YyJGy57YBrQ%25r90nDW8zWuBDjqogqaYS6l3ilUE0mcRScHFrVMbnMdjfOyJGy5sKbrQ%25r915iW8zg6FNIRq46lhoqoQEdcNq0zxcqW8JuzM8nq0z6Fboy6oEd82";  // BMW image URL
  const kiaImageUrl = "https://file.kelleybluebookimages.com/kbb/base/evox/CP/13275/2020-Kia-Sedona-front_13275_032_2400x1800_SWP.png";  // KIA image URL
  const defaultImageUrl = "https://www.iihs.org/cdn-cgi/image/width=636/api/ratings/model-year-images/3035/";
  const fordImageUrl = "https://file.kelleybluebookimages.com/kbb/base/evox/CP/13035/2019-Ford-Fusion-front_13035_032_1793x740_FT_cropped.png";
  const ramImageUrl = "https://di-uploads-pod12.dealerinspire.com/glennsfreedomdcjr/uploads/2022/04/2022-Ram-2500-Olive-Green-Pearl-Coat-Exterior-Paint-and-Diamond-Black-Crystal-Pearl-Coat-Exterior-Paint.png";

  return (
    <Container>
      <Typography variant="h4" gutterBottom>Available Cars</Typography>

      {/* Filters */}
      <Box sx={{ marginBottom: 2 }}>
        <TextField
          label="Min Price"
          type="number"
          value={filters.minPrice}
          name="minPrice"
          onChange={handleFilterChange}
          sx={{ marginRight: 2 }}
        />
        <TextField
          label="Max Price"
          type="number"
          value={filters.maxPrice}
          name="maxPrice"
          onChange={handleFilterChange}
          sx={{ marginRight: 2 }}
        />
        <TextField
          label="Brand"
          type="text"
          value={filters.brand}
          name="brand"
          onChange={handleFilterChange}
          sx={{ marginRight: 2 }}
        />
      </Box>

      {/* Sort Options */}
      <Box sx={{ marginBottom: 2 }}>
        <select value={sortOption} onChange={handleSortChange}>
          <option value="">Sort By</option>
          <option value="priceLowToHigh">Price: Low to High</option>
          <option value="priceHighToLow">Price: High to Low</option>
          <option value="MileageLowToHigh">Mileage: Low to High</option>
          <option value="MileageHighToLow">Mileage: High to Low</option>
          <option value="YearLowToHigh">Year: Oldest to Newest</option>
          <option value="YearHighToLow">Year: Newest to Oldest</option>
        </select>
      </Box>

      <Grid container spacing={2}>
        {sortedItems.map(item => (
          <Grid item xs={12} sm={6} md={4} key={item.id}>
            <Card sx={{ padding: 2 }}>
              <CardContent>
                <Typography variant="h7">  <Link to={`/car/${item.id}`}> {item.year} {item.brand} {item.color} {item.shape}</Link></Typography>

                {/* Display car image based on model */}
                <img 
                  src={item.brand.toUpperCase() === 'SUBARU' ? subaruImageUrl : 
                        item.brand.toUpperCase() === 'NISSAN' ? nissanImageUrl : 
                        item.brand.toUpperCase() === 'MERCEDES_BENZ' ? mercedesBenzImageUrl : 
                        item.brand.toUpperCase() === 'RIVIAN' ? rivianImageUrl :
                        item.brand.toUpperCase() === 'HONDA' ? hondaImageUrl : 
                        item.brand.toUpperCase() === 'TOYOTA' ? toyotaImageUrl :
                        item.brand.toUpperCase() === 'FORD' ? fordImageUrl : 
                        item.brand.toUpperCase() === 'RAM' ? ramImageUrl : 
                        item.brand.toUpperCase() === 'JEEP' ? jeepImageUrl : 
                        item.brand.toUpperCase() === 'BMW' ? bmwImageUrl : 
                        item.brand.toUpperCase() === 'KIA' ? kiaImageUrl :  // Check for KIA
                        defaultImageUrl + item.model + '.jpg'} 
                  alt={`${item.brand} ${item.model}`} 
                  style={{ width: '100%', height: 'auto', marginBottom: '10px' }} 
                />

                <Typography variant="body1">Price: ${item.price}</Typography>
                <Typography variant="body1">Mileage: {item.mileage}</Typography>
                <Typography variant="body1">Quantity: {item.quantity}</Typography>
                <Button variant="contained" color="primary" onClick={() => addToCart(item)} disabled={item.quantity <= 0}>
                  {item.quantity > 0 ? "Add to Cart" : "Sold Out"}
                </Button>
              </CardContent>
            </Card>
          </Grid>
        ))}
      </Grid>
    </Container>
  );
};



// Main App Component
const App = () => {
  const [cartItems, setCartItems] = useState([]);
  const [siteReview, setSiteReview] = useState(null);
  const [submitted, setSubmitted] = useState(false);
  const [reviews, setReviews] = useState([]);
  const [loggedStatus, setLoggedStatus] = useState(false)


  const changeLoggedStatus = () => {
    setLoggedStatus(!loggedStatus);
  };

  const addToCart = (item) => {
    // Check if the item is already in the cart
    const itemInCart = cartItems.find(cartItem => cartItem.id === item.id);

    // If item exists in cart, check if the quantity is less than the available quantity
    if (itemInCart) {
      if (itemInCart.quantity < item.quantity) {
        // If we can still add more, update the quantity
        itemInCart.quantity += 1;
        setCartItems([...cartItems]);
      } else {
        alert("You cannot add more than the available quantity.");
      }
    } else {
      // If item doesn't exist in the cart, add it with quantity 1
      setCartItems([...cartItems, { ...item, quantity: 1 }]);
    }
  };

  const removeFromCart = (itemId) => {
    // Find the index of the item to be removed
    const updatedCart = [...cartItems];
    const indexToRemove = updatedCart.findIndex(item => item.id === itemId);

    if (indexToRemove !== -1) {
      const itemToRemove = updatedCart[indexToRemove];

      // If quantity is greater than 1, decrease the quantity
      if (itemToRemove.quantity > 1) {
        itemToRemove.quantity -= 1;
      } else {
        // If quantity is 1, remove the item from the cart completely
        updatedCart.splice(indexToRemove, 1);
      }

      // Update the cart with the new list
      setCartItems(updatedCart);
    }
  };
  const handleReviewSubmit = (newReview) => {
    setReviews([...reviews, newReview]);
    setSiteReview(newReview);
    setSubmitted(true);

    // Send the new review to the backend (assuming an endpoint for reviews exists)
    axios.post('http://localhost:5000/reviews', newReview)
      .then(response => {
        console.log("Review submitted:", response.data);
      })
      .catch(error => {
        console.error("Error submitting review:", error);
      });
  };

  return (
    <Router>
      <AppBar position="static">
        <Toolbar>
        <img src={logo} alt="AutoHaven Logo" style={{ maxWidth: 100, marginRight: 20 }} />
        <Typography variant="h6" sx={{ flexGrow: 1 }}></Typography>
          <Button color="inherit" component={Link} to="/"><HomeIcon /></Button>
          <Button color="inherit" component={Link} to="/loan">Financing</Button>
          <Button color="inherit" component={Link} to="/cars">Inventory</Button>
          <Button color="inherit" component={Link} to="/deals">Hot Deals</Button>
          <Button color="inherit" component={Link} to="/cart">Cart ({cartItems.length})</Button>
          <Button color="inherit" component={Link} to="/login"> <PersonOutlineIcon />{Cookies.get("user_id") ? "Logout" :""}</Button>

        </Toolbar>
      </AppBar>

      <Box sx={{ display: 'flex', flexDirection: 'column', minHeight: '100vh' }}>
        <Container sx={{ flexGrow: 1, marginTop: 3 }}>
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/loan" element={<LoanCalculator />} />
            <Route path="/cars" element={<ItemList addToCart={addToCart} />} />
            <Route path="/cart" element={<Cart cartItems={cartItems} setCartItems={setCartItems} removeFromCart={removeFromCart} />} />
            <Route path="/review" element={<ReviewButton onReviewSubmit={handleReviewSubmit} />} />
            <Route path="/all-reviews" element={<AllReviews />} />
            <Route path="/login" element={<Login changeLoggedStatus={changeLoggedStatus} />} />
            <Route path="/deals" element={<HotDeals addToCart={addToCart} />} />
            <Route path="/car/:id" element={<ItemDetail />} />
            <Route path="/signup" element={<SignUp />} />
          </Routes>
        </Container>
        <BrandShowcase />

        
      </Box>
      {submitted && siteReview && (
        <Box sx={{ padding: 2, backgroundColor: 'lightgreen' }}>
          <Typography variant="h6">Thank you for your review!</Typography>
          <Typography variant="body1">{siteReview.comment}</Typography>
          <Typography variant="body2">Rating: {siteReview.rating} Stars</Typography>
        </Box>
      )}
    </Router>
  );
};

export default App;
