import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';
import Cookies from 'js-cookie';
import { BrowserRouter as Router, Route, Routes, Link } from 'react-router-dom';
import './Home.css';

const Home = () => {
  const [reviews, setReviews] = useState([]);
  const [receipts, setReceipts] = useState([]);
  const [clicked, setClicked] = useState(null);  // Default to null, nothing selected initially
  const [items, setItems] = useState([]);

  useEffect(() => {
    if (Cookies.get('user_id')) {
      axios
        .get('http://localhost:5000/userReviews/' + Cookies.get('user_id'))
        .then((response) => {
          setReviews(response.data.dto || []);
        })
        .catch((error) => {
          console.error('Error fetching reviews:', error);
        });

      axios
        .get('http://localhost:5000/userReceipts/' + Cookies.get('user_id'))
        .then((response) => {
          setReceipts(response.data);
        })
        .catch((error) => {
          console.error('Error fetching receipts:', error);
        });

      axios
        .get('http://localhost:5000/items')
        .then((response) => {
          setItems(response.data);
        })
        .catch((error) => {
          console.error('Error fetching items:', error);
        });
    }
  }, []);

  const getItemInfo = (id) => {
    const item = items.find((item) => item.id === id);
    return item ? `${item.year} ${item.brand} ${item.color} ${item.shape}` : '';
  };

  if (!Cookies.get('user_id'))
    return (
      <div className="welcome-container">
        <h1 className="welcome-title">Welcome to <strong>AutoHaven</strong></h1>
        <p className="welcome-subtitle">
          Start your journey today and discover your perfect car
        </p>
        <div className="feature-list">
          <ul>
            <li>
              <span className="icon">⭐</span>
              <span className="feature-title">Premium Selection</span>
              <p>Handpicked vehicles from renowned global manufacturers, ensuring the finest quality and performance</p>
            </li>
            <li>
              <span className="icon">🔍</span>
              <span className="feature-title">Advanced Search Filters</span>
              <p>Find the perfect vehicle with our search filters, allowing you to refine results based on your preferences</p>
            </li>
            <li>
              <span className="icon">💰</span>
              <span className="feature-title">Flexible Financing</span>
              <p>Explore flexible payment options with competitive interest rates</p>
              <p>Use our intuitive loan calculator to easily estimate your monthly payments</p>
            </li>
            <li>
              <span className="icon">🔥</span>
              <span className="feature-title">Amazing Deals</span>
              <p>We offer exceptional discounts on select vehicles</p>
              <p>Take advantage of our limited-time offers</p>
            </li>
            <li>
              <span className="icon">🤝</span>
              <span className="feature-title">Expert Support</span>
              <p>Dedicated team of automotive experts at your service</p>
              <p>24/7 Chatbot support ready to answer your questions</p>
            </li>
            <li>
              <span className="icon">🔑</span>
              <span className="feature-title">Account Benefits</span>
              <p>Unlock a personalized experience by creating an account</p>
              <p>Enjoy features like tracking your purchases, leaving reviews, and accessing exclusive offers</p>
            </li>
          </ul>
        </div>
      </div>
    );

  return (
    <div className="home-container">
      <h2>Welcome, {Cookies.get('username')} to your profile dashboard</h2>
      <div className="button-container">
        <button className="toggle-btn" onClick={() => setClicked('reviews')}>
          <b>Review History</b>
        </button>
        <button className="toggle-btn" onClick={() => setClicked('purchases')}>
          <b>Purchase History</b>
        </button>
      </div>

      {/* Only show sections when clicked */}
      {clicked === 'reviews' && (
        <div className="history-section">
          <h3>Your Review History</h3>
          {reviews.length === 0 ? (
            <h2>No reviews available yet.</h2>
          ) : (
            reviews.map((review) => (
              <div className="review-card" key={review.review.id}>
                <h4>
                  Review for: <Link to={`/car/${review.review.item_id}`}>{review.itemDetails}</Link>
                </h4>
                <p>Rating: {review.review.rating}</p>
                <p>
                  Date: {new Date(review.review.created).toLocaleDateString()} at{' '}
                  {new Date(review.review.created).toLocaleTimeString()}
                </p>
                <p>{review.review.comment}</p>
              </div>
            ))
          )}
        </div>
      )}

      {clicked === 'purchases' && (
        <div className="history-section">
          <h3>Your Purchase History</h3>
          {receipts.length === 0 ? (
            <h2>No purchases found.</h2>
          ) : (
            receipts.map((receipt) => (
              <div className="receipt-card" key={receipt.id}>
                <h4>Receipt ID: {receipt.id}</h4>
                <p><b>Total: ${receipt.total}</b></p>
                {receipt.orders.map((order) => (
                  <div key={order.item_id}>
                    <p>
                      <Link to={`/car/${order.item_id}`}>
                        {getItemInfo(order.item_id)}
                      </Link>
                    </p>
                    <p>Price: ${order.price}</p>
                    <p>Quantity: {order.quantity}</p>
                    <p>Subtotal: ${order.subtotal}</p>
                    <hr />
                  </div>
                ))}
              </div>
            ))
          )}
        </div>
      )}
    </div>
  );
};

export default Home;
