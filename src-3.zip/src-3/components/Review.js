import React, { useState } from 'react';
import axios from 'axios';

const ReviewForm = ({ itemId, onReviewSubmit }) => {
  const [rating, setRating] = useState(1);
  const [comment, setComment] = useState('');
  const [error, setError] = useState('');

  const handleRatingChange = (e) => {
    setRating(e.target.value);
  };

  const handleCommentChange = (e) => {
    setComment(e.target.value);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    if (!comment.trim()) {
      setError('Please provide a comment.');
      return;
    }

    try {
      const newReview = {
        item_id: itemId,
        rating: rating,
        comment: comment,
        created: new Date(),
      };

      // Post the new review to the backend
      const response = await axios.post('http://localhost:5000/reviews', newReview);
      
      // Notify parent component that review was submitted successfully
      onReviewSubmit(response.data); // Add review to the list in parent component
      setRating(1);
      setComment('');
      setError('');
    } catch (err) {
      console.error('Error submitting review:', err);
      setError('Failed to submit review. Please try again.');
    }
  };

  return (
    <div>
      <h3>Leave a Review</h3>
      <form onSubmit={handleSubmit}>
        <div>
          <label>Rating: </label>
          <select value={rating} onChange={handleRatingChange}>
            {[1, 2, 3, 4, 5].map((star) => (
              <option key={star} value={star}>
                {star} Star{star > 1 ? 's' : ''}
              </option>
            ))}
          </select>
        </div>
        <div>
          <label>Comment: </label>
          <textarea
            value={comment}
            onChange={handleCommentChange}
            rows="4"
            placeholder="Write your review..."
          />
        </div>
        {error && <p style={{ color: 'red' }}>{error}</p>}
        <button type="submit">Submit Review</button>
      </form>
    </div>
  );
};

export default ReviewForm;
