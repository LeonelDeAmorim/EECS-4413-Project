import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { Box, Typography, Rating, Container } from '@mui/material';

const AllReviews = () => {
  const [reviews, setReviews] = useState([]);

  useEffect(() => {
    const fetchReviews = async () => {
      try {
        const response = await axios.get('http://localhost:5000/reviews');  // Ensure your API endpoint is correct
        setReviews(response.data);
      } catch (error) {
        console.error('Error fetching reviews:', error);
      }
    };

    fetchReviews();  // Fetch reviews when component mounts
  }, []);

  return (
    <Container>
      <Typography variant="h4" gutterBottom>All Reviews</Typography>
      {reviews.length === 0 ? (
        <Typography>No reviews available.</Typography>
      ) : (
        reviews.map((review) => (
          <Box key={review.id} sx={{ marginBottom: '20px', padding: '15px', border: '1px solid #ccc', borderRadius: '8px' }}>
            <Typography variant="h6">{`Rating:`}</Typography>
            <Rating value={review.rating} readOnly precision={0.5} sx={{ marginBottom: '10px' }} />
            <Typography variant="body1">{review.comment}</Typography>
            <Typography variant="body2" color="textSecondary">{`User ID: ${review.user_id}`}</Typography>
            <Typography variant="body2" color="textSecondary">{`Item ID: ${review.item_id}`}</Typography>
            <Typography variant="body2" color="textSecondary">{`Created: ${new Date(review.created).toLocaleDateString()}`}</Typography>
          </Box>
        ))
      )}
    </Container>
  );
};

export default AllReviews;
