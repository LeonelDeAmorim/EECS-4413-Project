import React, { useState } from 'react';
import axios from 'axios';
import { TextField, Button, Typography, Box, Paper, Container, Alert } from '@mui/material';

const SignUp = () => {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [message, setMessage] = useState('');

  const handleSubmit = async (e) => {
    e.preventDefault();

    if (username.length < 4 || password.length < 4) {
      setMessage('Username and password must be at least 4 characters long.');
      setTimeout(() => setMessage(''), 10000);
      return;
    }

    try {
      const response = await axios.post('http://localhost:5000/users', { username, password });
      if (response.status === 201) {
        setMessage('Successfully created user account: ' + username);
        setUsername('');
        setPassword('');
      }
    } catch (error) {
      if (error.response) {
        if (error.response.status === 400) {
          setMessage(`${username} is already taken, please choose another username`);
        }
      } else {
        setMessage('An unexpected error occurred. Please try again.');
      }
    }
  };

  return (
    <Container component="main" maxWidth="xs">
      <Paper sx={{ padding: 4, display: 'flex', flexDirection: 'column', alignItems: 'center' }}>
        <Typography variant="h5" gutterBottom>
          Sign Up
        </Typography>
        <form onSubmit={handleSubmit} style={{ width: '100%' }}>
          <TextField
            variant="outlined"
            margin="normal"
            required
            fullWidth
            label="Username"
            value={username}
            onChange={(e) => setUsername(e.target.value)}
          />
          <TextField
            variant="outlined"
            margin="normal"
            required
            fullWidth
            label="Password"
            type="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
          />
          <Button type="submit" fullWidth variant="contained" color="primary" sx={{ mt: 2 }}>
            Sign Up
          </Button>
          {message && (
            <Box sx={{ mt: 2 }}>
              <Alert severity={message.includes('Successfully') ? 'success' : 'error'}>
                {message}
              </Alert>
            </Box>
          )}
        </form>
      </Paper>
    </Container>
  );
};

export default SignUp;
