import React from 'react';
import './BrandsShowcase.css'; // Make sure the correct path to CSS is used

const BrandShowcase = () => {
  const brands = [
    { id: 1, name: 'Toyota', logo: 'https://upload.wikimedia.org/wikipedia/commons/thumb/e/e7/Toyota.svg/250px-Toyota.svg.png' },
    { id: 2, name: 'Ford', logo: 'https://upload.wikimedia.org/wikipedia/commons/thumb/3/3e/Ford_logo_flat.svg/250px-Ford_logo_flat.svg.png' },
    { id: 3, name: 'Honda', logo: 'https://upload.wikimedia.org/wikipedia/commons/thumb/3/38/Honda.svg/275px-Honda.svg.png' },
    { id: 4, name: 'BMW', logo: 'https://upload.wikimedia.org/wikipedia/commons/thumb/4/44/BMW.svg/220px-BMW.svg.png' },
    { id: 5, name: 'Chevrolet', logo: 'https://upload.wikimedia.org/wikipedia/en/thumb/b/bd/Chevrolet_%28logo%29.svg/250px-Chevrolet_%28logo%29.svg.png' },
    { id: 6, name: 'RAM', logo: 'https://upload.wikimedia.org/wikipedia/en/thumb/e/e8/Ramchryslerlogo.png/220px-Ramchryslerlogo.png' },
    { id: 7, name: 'Mercedes-Benz', logo: 'https://upload.wikimedia.org/wikipedia/commons/thumb/9/9e/Mercedes-Benz_Logo_2010.svg/250px-Mercedes-Benz_Logo_2010.svg.png' },
    { id: 8, name: 'Nissan', logo: 'https://upload.wikimedia.org/wikipedia/commons/thumb/2/23/Nissan_2020_logo.svg/250px-Nissan_2020_logo.svg.png' },
    { id: 9, name: 'Kia', logo: 'https://upload.wikimedia.org/wikipedia/commons/thumb/b/b6/KIA_logo3.svg/120px-KIA_logo3.svg.png' },
    { id: 10, name: 'Rivian', logo: 'https://upload.wikimedia.org/wikipedia/commons/thumb/3/3f/Rivian_logo_and_wordmark.svg/250px-Rivian_logo_and_wordmark.svg.png' },
    { id: 11, name: 'Subaru', logo: 'https://upload.wikimedia.org/wikipedia/commons/thumb/c/ca/Subaru_logo_%28transparent%29.svg/250px-Subaru_logo_%28transparent%29.svg.png' },


    // Add more brand logos as needed
  ];
  return (
    <div className="brand-showcase">
      <div className="brand-showcase-inner">
        {/* First set of logos */}
        {brands.map((brand) => (
          <div className="brand-item" key={brand.id}>
            <img src={brand.logo} alt={brand.name} />
          </div>
        ))}

        {/* Second set of logos (same as first one, for infinite effect) */}
        {brands.map((brand) => (
          <div className="brand-item" key={brand.id + '-copy'}>
            <img src={brand.logo} alt={brand.name} />
          </div>
        ))}
      </div>
    </div>
  );
};

export default BrandShowcase;
