import React, { useState } from "react";
import { Container, Button, Typography, Grid, Card, CardContent, Box, TextField, Select, MenuItem, InputLabel, FormControl, FormHelperText, Divider } from '@mui/material';
import Cookies from "js-cookie";
import axios from 'axios';

const carImages = {
  "2019 NISSAN": "https://file.kelleybluebookimages.com/kbb/base/evox/CP/13188/2019-Nissan-Frontier%20Crew%20Cab-front_13188_032_1878x829_KAD_cropped.png",
  "2017 SUBARU": "https://file.kelleybluebookimages.com/kbb/base/evox/CP/10961/2017-Subaru-Forester-front_10961_032_1848x898_J8U_cropped.png",
  "2020 KIA": "https://file.kelleybluebookimages.com/kbb/base/evox/CP/13275/2020-Kia-Sedona-front_13275_032_2400x1800_SWP.png",
  "2021 MERCEDES_BENZ": "https://di-shared-assets.dealerinspire.com/legacy/rackspace/ldm-images/2021-Mercedes-Benz-E-Class-Sedan-colour-Selenite-Grey-metallic.png",

};

const Cart = ({ cartItems, setCartItems, removeFromCart }) => {
  const [toggleCart, setToggleCart] = useState(true);
  const [toggleCheckout, setToggleCheckout] = useState(false);
  const [payment, setPayment] = useState(false);
  const [checkOutResponse, setCheckOutResponse] = useState([]);
  const totalAmount = cartItems.reduce((total, item) => total + (item.price * item.quantity), 0);

  const toggleForm = () => {
    setToggleCart(!toggleCart);
    setToggleCheckout(!toggleCheckout);
  };

  const provinces = [
    "Alberta", "British Columbia", "Manitoba", "New Brunswick", "Newfoundland and Labrador", 
    "Nova Scotia", "Ontario", "Prince Edward Island", "Quebec", "Saskatchewan"
  ];

  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const [form, setForm] = useState({
    cardNumber: "",
    expiryDate: "",
    ccv: "",
    city: "",
    province: ""
  });

  const Checkout = async (event) => {
    event.preventDefault();
    if (!Cookies.get("user_id"))
      if (!window.confirm("You haven't logged in, without logging in you cannot rate your purchase"))
        return;

    const body = cartItems.map(item => ({
      id: item.id,
      quantity: item.quantity
    }));

    const optional = Cookies.get("user_id") ? `?user_id=${Cookies.get("user_id")}` : "";
    const reference = cartItems.map(item => ({
      id: item.id,
      quantity: item.quantity,
      brand: item.brand,
      color: item.color,
      price: item.price,
      subtotal: item.price * item.quantity
    }));
    try {
      const response = await axios.post(`http://localhost:5000/checkout${optional}`, body);
      if (response.status === 201 || response.status === 200) {
        setCheckOutResponse(response.data);
        setCartItems([]);  
      }
    } catch (error) {
      console.error("Error", error);
    }
    setToggleCheckout(false);
  };

  if (toggleCart) {
    return (
      <Container>
        <Typography variant="h4" gutterBottom></Typography>
       {cartItems.length === 0 ? (
  <Typography variant="h4" gutterBottom>
    Currently no items in your cart
  </Typography>
        ) : null}
        <Grid container spacing={3}>
          {cartItems.map((item, index) => {
            // Generate the unique key for each car (can be a combination of year and brand/model)
            const carKey = `${item.year} ${item.brand}`;
            const carImage = carImages[carKey];

            return (
              <Grid item xs={12} sm={6} md={4} key={index}>
                <Card sx={{ display: 'flex', flexDirection: 'column', padding: 2 }}>
                  <CardContent sx={{ textAlign: 'center' }}>
                    {/* Show car image */}
                    {carImage && <img src={carImage} alt={carKey} style={{ width: '100%', height: '200px', objectFit: 'cover' }} />}
                    <Typography variant="h6" sx={{ marginTop: 2 }}>{item.brand} - {item.shape}</Typography>
                    <Typography variant="body2">Quantity: {item.quantity || 1}</Typography>
                    <Button
               variant="outlined"
              color="secondary"
              
             onClick={() => removeFromCart(item.id)}
             sx={{
                   marginTop: 2,
                   color: '#000000',  // White text color when hovered
                   borderColor:'#000000',
                            '&:hover': {
                     backgroundColor: 'red', // Set background color to red on hover
                   borderColor: 'red', // Optional: Change border color to match
                  color: '#fff', // Optional: Change text color to white when hovered
    },
  }}
>
  Remove
                    </Button>
                  </CardContent>
                </Card>
              </Grid>
            );
          })}
        </Grid>
        {/* Checkout button below the cart items */}
        <Button variant="contained" color="primary" onClick={toggleForm} sx={{ marginTop: '20px', display: cartItems.length > 0 ? "block" : "none" }}>
          Proceed to Checkout
        </Button>
      </Container>
    );
  }

  if (toggleCheckout) {
    return (
      <>
        <Container>
          <Typography variant="h4" gutterBottom>Review Cart Items</Typography>
          <table border="1" style={{ margin: '20px', width: '100%' }}>
            <thead>
              <tr>
                <th>Item</th>
                <th>Quantity</th>
                <th>Price</th>
                <th>Subtotal</th>
              </tr>
            </thead>
            <tbody>
              {cartItems.map((item) => (
                <tr key={item.id}>
                  <td>{item.year} {item.brand} {item.color} {item.shape} {item.condition.split('_')[0]} {item.condition.split('_')[1] ? " " + item.condition.split('_')[1] : ""}</td>
                  <td style={{ textAlign: 'right' }}>{item.quantity}</td>
                  <td style={{ textAlign: 'right' }}>${item.price}</td>
                  <td style={{ textAlign: 'right' }}>${item.price * item.quantity}</td>
                </tr>
              ))}
            </tbody>
            <tfoot>
              <tr>
                <td colSpan="3" style={{ textAlign: 'left' }}>Total</td>
                <td style={{ textAlign: 'right' }}>${totalAmount}</td>
              </tr>
            </tfoot>
          </table>
        </Container>

        <Container sx={{ marginTop: '30px' }}>
          <Typography variant="h5" gutterBottom>Credit Card Information</Typography>
          <form onSubmit={Checkout}>
            <TextField
              label="Full Name"
              name="FullName"
              placeholder="First Last"
              variant="outlined"
              fullWidth
              sx={{ marginBottom: 2 }}
            />
            <TextField
              label="Credit Card Number"
              name="cardNumber"
              value={form.cardNumber}
              onChange={handleChange}
              placeholder="1234 5678 9012 3456"
              maxLength="16"
              variant="outlined"
              fullWidth
              sx={{ marginBottom: 2 }}
            />
            <Grid container spacing={2}>
              <Grid item xs={6}>
                <TextField
                  label="Expiry Date"
                  name="expiryDate"
                  value={form.expiryDate}
                  onChange={handleChange}
                  placeholder="MM/YY"
                  variant="outlined"
                  fullWidth
                  sx={{ marginBottom: 2 }}
                />
              </Grid>
              <Grid item xs={6}>
                <TextField
                  label="CCV"
                  name="ccv"
                  value={form.ccv}
                  onChange={handleChange}
                  placeholder="123"
                  maxLength="3"
                  variant="outlined"
                  fullWidth
                  sx={{ marginBottom: 2 }}
                />
              </Grid>
            </Grid>
            <TextField
              label="City"
              name="city"
              value={form.city}
              onChange={handleChange}
              placeholder="City"
              variant="outlined"
              fullWidth
              sx={{ marginBottom: 2 }}
            />
            <TextField
              label="Street Address"
              placeholder="123 St. Street"
              variant="outlined"
              fullWidth
              sx={{ marginBottom: 2 }}
            />
            <TextField
              label="Postal Code"
              placeholder="M1M 3WR"
              variant="outlined"
              fullWidth
              sx={{ marginBottom: 2 }}
            />
            <FormControl fullWidth sx={{ marginBottom: 2 }}>
              <InputLabel>Province</InputLabel>
              <Select
                name="province"
                value={form.province}
                onChange={handleChange}
              >
                {provinces.map((province, index) => (
                  <MenuItem key={index} value={province}>
                    {province}
                  </MenuItem>
                ))}
              </Select>
              <FormHelperText>Choose the province where you reside.</FormHelperText>
            </FormControl>

            <Button variant="contained" color="primary" type="submit" fullWidth>
              Proceed to Payment
            </Button>
            <Button
  variant="outlined"
  color="secondary"
  onClick={toggleForm}
  fullWidth
  sx={{
    marginTop: 2,
    color: '#000000',  // White text color when hovered

    '&:hover': {
      backgroundColor: '#c53030',  // Darker red on hover
      borderColor: '#c53030',  // Matching border color
      color: '#fff',  // White text color when hovered

    },
  }}
>              Go Back
            </Button>
          </form>
        </Container>
      </>
    );
  }
};

export default Cart;
