import React, { useState } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';
import Cookies from 'js-cookie';
import { TextField, Button, Typography, Box, Grid, Paper, Container } from '@mui/material';

const Login = ({ changeLoggedStatus }) => {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [status, setStatus] = useState(false);
  const navigate = useNavigate(); // For navigation after successful login

  const handleLogin = async (e) => {
    e.preventDefault();

    const data = { username, password };

    try {
      const response = await axios.post('http://localhost:5000/login', data);
      if (response.status === 200) {
        const { username, user_id } = response.data;
        Cookies.set('username', username, { expires: 1, sameSite: 'Lax' });
        Cookies.set('user_id', user_id, { expires: 1, sameSite: 'Lax' });
        console.log(username, user_id);
        changeLoggedStatus();
        navigate('/');
      }
    } catch (error) {
      console.log('An error has occurred', error);
      setError('Username/Password mismatch');
    }
  };

  const logOut = () => {
    Cookies.remove('user_id');
    Cookies.remove('username');
    setStatus(!status);
    changeLoggedStatus();
    navigate('/');
  };

  if (!Cookies.get('user_id')) {
    return (
      <Container component="main" maxWidth="xs">
        <Paper sx={{ padding: 4, display: 'flex', flexDirection: 'column', alignItems: 'center' }}>
          <Typography variant="h5" gutterBottom>
            Sign In
          </Typography>
          <form onSubmit={handleLogin} style={{ width: '100%' }}>
            <TextField
              variant="outlined"
              margin="normal"
              required
              fullWidth
              label="Username"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
            />
            <TextField
              variant="outlined"
              margin="normal"
              required
              fullWidth
              label="Password"
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
            />
            {error && <Typography color="error" variant="body2">{error}</Typography>}
            <Button type="submit" fullWidth variant="contained" color="primary" sx={{ mt: 2 }}>
              Login
            </Button>
            <Grid container justifyContent="flex-end" sx={{ mt: 2 }}>
              <Grid item>
                <Typography variant="body2">
                  Don't have an account? <a href="/signup">Sign Up</a>
                </Typography>
              </Grid>
            </Grid>
          </form>
        </Paper>
      </Container>
    );
  }

  return (
    <Box sx={{ display: 'flex', flexDirection: 'column', alignItems: 'center', mt: 4 }}>
      <Typography variant="h6">You are logged in! Click the button below to logout</Typography>
      <Button
      variant="contained"
      color="secondary"
      onClick={logOut}
      sx={{
      mt: 2,
       backgroundColor: '#3182ce', // Blue background by default
       '&:hover': {
        backgroundColor: '#e53e3e', // Red color on hover
       },
    }}
>

        Logout
      </Button>
    </Box>
  );
};

export default Login;
