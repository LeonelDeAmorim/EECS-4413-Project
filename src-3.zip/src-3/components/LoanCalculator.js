import React, { useState } from "react";
import axios from "axios";

const LoanCalculator = () => {
  const [showForm, setShowForm] = useState(false);

  // States for the loan inputs
  const [vehiclePrice, setVehiclePrice] = useState(0);
  const [downPayment, setDownPayment] = useState(0);
  const [interestRate, setInterestRate] = useState(0);
  const [duration, setDuration] = useState(0);
  const [monthlyPayment, setMonthlyPayment] = useState(null);

  const toggleForm = () => {
    setShowForm(!showForm);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    try {
      const response = await axios.get("http://localhost:5000/calculateLoan", {
        params: {
          vehiclePrice,
          downPayment,
          interestRate,
          duration,
        },
      });

      setMonthlyPayment(response.data.monthlyPayment);
    } catch (error) {
      console.error("Error fetching loan details:", error);
    }
  };

  return (
    <div>
      <h2>Loan Calculator</h2>

      {!showForm && (
        <button onClick={toggleForm}>Calculate Loan</button>
      )}

      {/* The form to input loan details */}
      {showForm && (
        <form onSubmit={handleSubmit}>
          <div>
            <label>Vehicle Price:</label>
            <input
              type="number"
              value={vehiclePrice}
              onChange={(e) => setVehiclePrice(e.target.value)}
              required
            />
          </div>
          <div>
            <label>Down Payment:</label>
            <input
              type="number"
              value={downPayment}
              onChange={(e) => setDownPayment(e.target.value)}
              required
            />
          </div>
          <div>
            <label>Interest Rate (%):</label>
            <input
              type="number"
              value={interestRate}
              onChange={(e) => setInterestRate(e.target.value)}
              required
            />
          </div>
          <div>
            <label>Duration (Months):</label>
            <input
              type="number"
              value={duration}
              onChange={(e) => setDuration(e.target.value)}
              required
            />
          </div>
          <button type="submit">Calculate Loan</button>
        </form>
      )}

      {/* Display monthly payment result */}
      {monthlyPayment !== null && (
        <div>
          <h3>Monthly Payment: ${monthlyPayment}</h3>
        </div>
      )}
    </div>
  );
};

export default LoanCalculator;
