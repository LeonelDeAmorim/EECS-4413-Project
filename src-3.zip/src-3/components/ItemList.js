import React, { useEffect, useState } from "react";
import axios from "axios";
import DOMPurify from "dompurify";

const ItemList = ({ addToCart }) => {
  const [items, setItems] = useState([]);
  const [filters, setFilters] = useState({
    minPrice: 0,
    maxPrice: 1000000,
    brand: '',
    condition: '',
    carShape: '',
  });
  const [sortOption, setSortOption] = useState('');

  // Mapping car models to their image URLs
  const carImages = {
    "2019 NISSAN": "https://file.kelleybluebookimages.com/kbb/base/evox/CP/13188/2019-Nissan-Frontier%20Crew%20Cab-front_13188_032_1878x829_KAD_cropped.png",
    "2017 SUBARU": "https://file.kelleybluebookimages.com/kbb/base/evox/CP/10961/2017-Subaru-Forester-front_10961_032_1848x898_J8U_cropped.png",
    "2020 KIA": "https://file.kelleybluebookimages.com/kbb/base/evox/CP/13275/2020-Kia-Sedona-front_13275_032_2400x1800_SWP.png",
    "2021 MERCEDES_BENZ": "https://di-shared-assets.dealerinspire.com/legacy/rackspace/ldm-images/2021-Mercedes-Benz-E-Class-Sedan-colour-Selenite-Grey-metallic.png",
    "2021 RAM": "https://www.iihs.org/cdn-cgi/image/width=636/api/ratings/model-year-images/3035/",
    "2021 TOYOTA": "https://www.iihs.org/cdn-cgi/image/width=636/api/ratings/model-year-images/3035/",
    // Add more cars and their images as needed
  };

  // Fetch items from API
  useEffect(() => {
    axios.get("http://localhost:5000/items")
      .then(response => {
        setItems(response.data);
      })
      .catch(error => {
        console.error("Error fetching items:", error);
      });
  }, []);

  // Handle filter changes
  const handleFilterChange = (event) => {
    const { name, value } = event.target;
    setFilters({
      ...filters,
      [name]: value,
    });
  };

  // Handle sorting option changes
  const handleSortChange = (event) => {
    setSortOption(event.target.value);
  };

  // Filter items based on selected filter values
  const filteredItems = items.filter(item => 
    item.price >= filters.minPrice && item.price <= filters.maxPrice &&
    (filters.brand ? item.brand.toLowerCase().includes(filters.brand.toLowerCase()) : true) &&
    (filters.condition ? item.condition.toLowerCase() === filters.condition.toLowerCase() : true) &&
    (filters.carShape ? item.shape.toLowerCase() === filters.carShape.toLowerCase() : true)
  );

  // Sort items based on selected sort option
  const sortedItems = filteredItems.sort((a, b) => {
    if (sortOption === 'priceLowToHigh') {
      return a.price - b.price;
    } else if (sortOption === 'priceHighToLow') {
      return b.price - a.price;
    }
    return 0;
  });

  // Function to get car image based on the brand and year
  const getCarImage = (item) => {
    const carKey = `${item.year} ${item.brand.toUpperCase()}`;
    return carImages[carKey] || "defaultCarImageURL"; // Return a default image if the car model is not found
  };

  return (
    <div>
      <h2>Available Cars</h2>
      
      {/* Filter Section */}
      <div>
        <input
          type="number"
          name="minPrice"
          placeholder="Min Price"
          value={filters.minPrice}
          onChange={handleFilterChange}
        />
        <input
          type="number"
          name="maxPrice"
          placeholder="Max Price"
          value={filters.maxPrice}
          onChange={handleFilterChange}
        />
        <input
          type="text"
          name="brand"
          placeholder="Brand"
          value={filters.brand}
          onChange={handleFilterChange}
        />
      </div>

      {/* Condition Filter */}
      <div>
        <select name="condition" value={filters.condition} onChange={handleFilterChange}>
          <option value="">Select Condition</option>
          <option value="new">New</option>
          <option value="usedDamaged">Used (Damaged)</option>
          <option value="usedUndamaged">Used (Undamaged)</option>
        </select>
      </div>

      {/* Car Shape Filter */}
      <div>
        <select name="carShape" value={filters.carShape} onChange={handleFilterChange}>
          <option value="">Select Car Shape</option>
          <option value="SUV">SUV</option>
          <option value="sedan">Sedan</option>
          <option value="pickup">Pickup</option>
          <option value="minivan">Minivan</option>
          <option value="sports">Sports</option>
          <option value="other">Other</option>
        </select>
      </div>

      {/* Sort Section */}
      <div>
        <select value={sortOption} onChange={handleSortChange}>
          <option value="">Sort By</option>
          <option value="priceLowToHigh">Price: Low to High</option>
          <option value="priceHighToLow">Price: High to Low</option>
        </select>
      </div>

      {/* Display Items */}
      <ul>
        {sortedItems.map(item => (
          <li key={item.id}>
            <div>
              {/* Show the car image */}
              <img src={getCarImage(item)} alt={`${item.year} ${item.brand} ${item.shape}`} />
            </div>
            <strong>Car ID:</strong> {item.id} | 
            <strong> Brand:</strong> {item.brand} | 
            <strong> Price:</strong> ${item.price} | 
            <strong> Quantity:</strong> {item.quantity} | 
            <strong> Condition:</strong> {item.condition} | 
            <strong> Shape:</strong> {item.shape}
            {/* Add to Cart button */}
            <button onClick={() => addToCart(item)} disabled={item.quantity <= 0}>Add to Cart</button>
          </li>
        ))}
      </ul>
    </div>
  );
};

export default ItemList;
