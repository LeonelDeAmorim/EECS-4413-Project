import React, { useState } from 'react';
import { TextField, Button, Typography, Box, Rating } from '@mui/material';

const ReviewForm = ({ onReviewSubmit }) => {
  const [rating, setRating] = useState(1);
  const [comment, setComment] = useState('');
  const [error, setError] = useState('');

  const handleRatingChange = (newValue) => {
    setRating(newValue);
  };

  const handleCommentChange = (e) => {
    setComment(e.target.value);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    if (!comment.trim()) {
      setError('Please provide a comment.');
      return;
    }

    const newReview = {
      rating: rating,
      comment: comment,
      created: new Date().toISOString(),
    };

    onReviewSubmit(newReview);
    setRating(1);
    setComment('');
    setError('');
  };

  return (
    <Box>
      <Typography variant="h5">Leave a Review</Typography>
      <form onSubmit={handleSubmit}>
        <Rating
          name="review-rating"
          value={rating}
          onChange={(_, newValue) => handleRatingChange(newValue)}
        />
        <TextField
          label="Comment"
          value={comment}
          onChange={handleCommentChange}
          fullWidth
          multiline
          rows={4}
          margin="normal"
        />
        {error && <Typography color="error">{error}</Typography>}
        <Button variant="contained" color="primary" type="submit" sx={{ marginTop: 2 }}>
          Submit Review
        </Button>
      </form>
    </Box>
  );
};

export default ReviewForm;
