import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { Container, Button, AppBar, Toolbar, Typography, Box, Grid, Card, CardContent, TextField } from '@mui/material';
import LocalOfferIcon from '@mui/icons-material/LocalOffer'; 

const carImages = {
  "2019 NISSAN": "https://file.kelleybluebookimages.com/kbb/base/evox/CP/13188/2019-Nissan-Frontier%20Crew%20Cab-front_13188_032_1878x829_KAD_cropped.png",
  "2017 SUBARU": "https://file.kelleybluebookimages.com/kbb/base/evox/CP/10961/2017-Subaru-Forester-front_10961_032_1848x898_J8U_cropped.png",
  "2020 KIA": "https://file.kelleybluebookimages.com/kbb/base/evox/CP/13275/2020-Kia-Sedona-front_13275_032_2400x1800_SWP.png",
  "2021 MERCEDES_BENZ": "https://di-shared-assets.dealerinspire.com/legacy/rackspace/ldm-images/2021-Mercedes-Benz-E-Class-Sedan-colour-Selenite-Grey-metallic.png",
  "2021 RAM": "https://cdn.motor1.com/images/mgl/golz4/s3/2020-ram-black-appearance-group.webp",
};

const HotDeals = ({ addToCart }) => {
  const [deals, setDeals] = useState([]);
  useEffect(() => {
    axios.get("http://localhost:5000/deals")
      .then(response => {
        setDeals(response.data);
      })
      .catch(error => {
        console.error("Error fetching items:", error);
      });
  }, []);

  const [filters, setFilters] = useState({
    minPrice: 0,
    maxPrice: 1000000,
    brand: '',
  });
  const [sortOption, setSortOption] = useState('');

  const handleFilterChange = (event) => {
    const { name, value } = event.target;
    setFilters({
      ...filters,
      [name]: value,
    });
  };

  const handleSortChange = (event) => {
    setSortOption(event.target.value);
  };

  const filteredItems = deals.filter(deal =>
    deal.item.price >= filters.minPrice && deal.item.price <= filters.maxPrice &&
    (filters.brand ? deal.item.brand.toLowerCase().includes(filters.brand.toLowerCase()) : true)
  );

  const sortedItems = filteredItems.sort((a, b) => {
    if (sortOption === 'priceLowToHigh') {
      return a.item.price - b.item.price;
    } else if (sortOption === 'priceHighToLow') {
      return b.item.price - a.item.price;
    } else if (sortOption === 'MileageLowToHigh') {
      return a.item.mileage - b.item.mileage;
    } else if (sortOption === 'MileageHighToLow') {
      return b.item.mileage - a.item.mileage;
    } else if (sortOption === 'YearHighToLow') {
      return b.item.year - a.item.year;
    } else if (sortOption === 'YearLowToHigh') {
      return a.item.year - b.item.year;
    } else if (sortOption === 'DiscountHighToLow') {
      return b.rate - a.rate;
    } else if (sortOption === 'DiscountLowToHigh') {
      return a.rate - b.rate;
    }
    return 0;
  });

  const getCarImage = (year, brand) => {
    const modelKey = `${year} ${brand.toUpperCase()}`;
    return carImages[modelKey] || ''; // Return the image URL if found, otherwise return an empty string
  };

  return (
    <Container>
      <Typography variant="h4" gutterBottom>HOT DEALS!!!!!!!</Typography>

      {/* Filters */}
      <Box sx={{ marginBottom: 2 }}>
        <TextField
          label="Min Price"
          type="number"
          value={filters.minPrice}
          name="minPrice"
          onChange={handleFilterChange}
          sx={{ marginRight: 2 }}
        />
        <TextField
          label="Max Price"
          type="number"
          value={filters.maxPrice}
          name="maxPrice"
          onChange={handleFilterChange}
          sx={{ marginRight: 2 }}
        />
        <TextField
          label="Brand"
          type="text"
          value={filters.brand}
          name="brand"
          onChange={handleFilterChange}
          sx={{ marginRight: 2 }}
        />
      </Box>

      {/* Sort Options */}
      <Box sx={{ marginBottom: 4 }}>
        <select value={sortOption} onChange={handleSortChange}>
          <option value="">Sort By</option>
          <option value="priceLowToHigh">Price: Low to High</option>
          <option value="priceHighToLow">Price: High to Low</option>
          <option value="MileageLowToHigh">Mileage: Low to High</option>
          <option value="MileageHighToLow">Mileage: High to Low</option>
          <option value="YearLowToHigh">Year: Oldest to Newest</option>
          <option value="YearHighToLow">Year: Newest to Oldest</option>
          <option value="DiscountLowToHigh">Discount: Lowest to Highest</option>
          <option value="DiscountHighToLow">Discount: Highest to Lowest</option>
        </select>
      </Box>

      <Grid container spacing={2}>
        {sortedItems.map(deal => (
          <Grid item xs={12} sm={6} md={4} key={deal.item.id}>
            <Card sx={{ padding: 2 }}>
              <CardContent>
                {/* Display the specific car image */}
                <img src={getCarImage(deal.item.year, deal.item.brand)} alt={deal.item.brand} style={{ width: '100%', height: 'auto' }} />
                
                <Typography variant="h6">{deal.item.year} {deal.item.brand} {deal.item.color} {deal.item.shape}</Typography>
                
                {/* Discount info */}
                <Box 
                  display="flex" 
                  alignItems="center" 
                  sx={{ 
                    backgroundColor: 'red', 
                    color: 'white', 
                    padding: '2px 8px', 
                    borderRadius: '12px', 
                    width: 'fit-content' 
                  }}
                >
                  <LocalOfferIcon sx={{ marginRight: 1, fontSize: '1.2rem' }} />
                  <Typography variant="h6" sx={{ fontWeight: 'bold' }}>DISCOUNT {deal.rate * 100}% OFF</Typography>
                </Box>

                <s><Typography variant="body1">Price: ${deal.old_price}</Typography></s>
                <Typography variant="body1">Price: ${deal.item.price}</Typography>
                <Typography variant="body1">Condition: {deal.item.condition}</Typography>
                <Typography variant="body1">Mileage: {deal.item.mileage} km</Typography>
                <Typography variant="body1">Quantity: {deal.item.quantity}</Typography>
                <Typography variant="body1">Sale Until: {(deal.endDate).split('T')[0]}</Typography>

                <Button variant="contained" color="primary" onClick={() => addToCart(deal.item)} disabled={deal.item.quantity <= 0}>
                  {deal.item.quantity > 0 ? "Add to Cart" : "Sold Out"}
                </Button>
              </CardContent>
            </Card>
          </Grid>
        ))}
      </Grid>
    </Container>
  );
};

export default HotDeals;
