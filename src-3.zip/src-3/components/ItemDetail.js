import React, { useEffect, useState } from 'react';
import { useParams } from 'react-router-dom';
import axios from 'axios';
import Cookies from 'js-cookie';
import DOMPurify from "dompurify";
import { Rating } from '@mui/material';

const ItemDetail = () => {
    const { id } = useParams();
    const [item, setItem] = useState(null);
    const [reviews, setReviews] = useState([]);
    const [rating, setRating] = useState(null);
    const [userRating, setUserRating] = useState(1); // This will be updated by the Rating component
    const [comment, setComment] = useState('');
    const [trigger, setTrigger] = useState(false);

    useEffect(() => {
        axios.get(`http://localhost:5000/items/${id}`)
            .then(response => {
                setItem(response.data);
            })
            .catch(error => console.error('Item get error:', error));

        axios.get(`http://localhost:5000/itemReviews/${id}`)
            .then(response => {
                setReviews(response.data.dto || []);
                setRating(response.data.score);
            })
            .catch(error => console.error('Review Get Error:', error));
    }, [id, trigger]);

    const handleDelete = async (reviewId) => {
        try {
            if (window.confirm("Are you sure you would like to delete your review for this product")) {
                const response = await axios.delete(`http://localhost:5000/reviews/${reviewId}`);
                if (response.status === 200)
                    setTrigger(!trigger);
            }
        }
        catch (error) {
            console.error('Error deleting review:', error);
            alert("An error occurred while deleting the review.");
        }
    }

    const handleSubmit = async (e) => {
        e.preventDefault();
        const safe = DOMPurify.sanitize(comment);

        if (!Cookies.get("user_id")) {
            alert("You must Login and Purchase the item before you can leave a review");
        } else {
            if (reviews.find(review => Number(review.review.user_id) === Number(Cookies.get("user_id")))) {
                alert("Your Review for this product already exists, please delete it and try submitting it again!");
            } else {
                const requestBody = {
                    user_id: Cookies.get("user_id"),
                    item_id: item.id,
                    rating: userRating,
                    comment: safe,
                    created: new Date().toISOString(),
                };

                try {
                    const response = await axios.post(`http://localhost:5000/reviews`, requestBody);

                    if (response.status === 200) {
                        setTrigger(!trigger);
                    }
                    setComment('');
                } catch (error) {
                    console.error('Error submitting review:', error);
                    if (error.response && error.response.status === 403) {
                        alert("Please Purchase the item before leaving a review");
                    }
                }
            }
        }
    };

    if (!item) return <p>Loading item details...</p>;

    return (
        <>
            <div>
                <h2>Item Details</h2>
                <ul>
                    <li><b>Brand:</b> {item.brand}</li>
                    <li><b>Shape:</b> {item.shape}</li>
                    <li><b>Year:</b> {item.year}</li>
                    <li><b>Rating:</b> {(rating !== null && rating >= 1) ? rating : "not available"}</li>
                    <li><b>Condition:</b> {item.condition}</li>
                    <li><b>Color:</b> {item.color}</li>
                    <li><b>Mileage:</b> {item.mileage} km</li>
                    <li><b>Price:</b> ${item.price}</li>
                </ul>
            </div>

            <div>
                <h4><u>User Reviews</u></h4>
                <form onSubmit={handleSubmit}>
                    <div>
                        <label>
                            Rating:
                            <Rating
                                value={userRating}
                                onChange={(event, newValue) => setUserRating(newValue)}
                                precision={0.5} // Allows half-star ratings
                                size="large"
                            />
                        </label>
                    </div>
                    <br />
                    <div>
                        <label>
                            Leave your review: <br />
                            <textarea
                                value={comment}
                                onChange={(e) => setComment(e.target.value)}
                                placeholder="Enter your review here..."
                                rows="6"
                                cols="120"
                            />
                        </label>
                    </div>
                    <button type="submit">Submit</button>
                </form>

                <ul>
                    {reviews.map(review => (
                        <li key={review.review.id}>
                            <b>User: {Cookies.get('username')}</b><br />
                            <b>Rating:</b> <Rating value={review.review.rating} readOnly precision={0.5} /> / 5.0
                            <br />
                            <b>Comment:</b> {review.review.comment}
                            <br />
                            <b>Posted:</b> {review.review.created.split('T')[0]} {review.review.created.split('T')[1]}
                            <br />

                            {Number(review.review.user_id) === Number(Cookies.get("user_id")) && (
                                <button onClick={() => handleDelete(review.review.id)}>
                                    Delete
                                </button>
                            )}
                        </li>
                    ))}
                </ul>
            </div>
        </>
    );
};

export default ItemDetail;
