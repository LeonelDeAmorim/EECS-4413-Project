package application.model;

public enum Condition {
NEW,USED_DAMAGED,USED_UNDAMAGED
}
