package application.model;

public enum Brand {
	 TOYOTA,FORD,HONDA,BMW,MERCEDES_BENZ,NISSAN,KIA,RIVIAN,JEEP,RAM,SUBARU;
}
