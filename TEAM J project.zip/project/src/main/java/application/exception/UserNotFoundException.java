package application.exception;

public class UserNotFoundException extends RuntimeException{

	public UserNotFoundException(Long id) {
	System.out.println("User not found");
	}

}
