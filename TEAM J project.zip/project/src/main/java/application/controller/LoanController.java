package application.controller;


import application.service.LoanCalculator;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

//changed from restcontroller to display functionality will change when frontend developed
@Controller
public class LoanController {
	@Autowired
    private LoanCalculator loanCalculator;

    @GetMapping("/")
    public String index() {
        return "index";
    }

    
    @GetMapping("/loanCalculator")
    public String loanCalculatorPage() {
        return "loanCalculator";
    }

    @RequestMapping("/calculateLoan")
    public String calculateLoan(@RequestParam("vehiclePrice") double vehiclePrice,
                                @RequestParam("downPayment") double downPayment,
                                @RequestParam("interestRate") double interestRate,
                                @RequestParam("duration") int duration,
                                org.springframework.ui.Model model) {

        double monthlyPayment = loanCalculator.CalculateLoan(vehiclePrice, downPayment, interestRate, duration);
        
        model.addAttribute("monthlyPayment", monthlyPayment);  
        
        return "loanCalculator"; 
    }
}
