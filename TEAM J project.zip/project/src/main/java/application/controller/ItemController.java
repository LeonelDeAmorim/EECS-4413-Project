package application.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import application.exception.ItemNotFoundException;
import application.model.Item;
import application.repository.ItemRepository;

//changed from restcontroller to display functionality will change when frontend developed
@Controller
public class ItemController {

	private final ItemRepository repository;

	ItemController(ItemRepository repository) {
		this.repository = repository;
	}

	//@GetMapping("/items")
	//List<Item> all() {
	//	List<Item> all = new ArrayList<>();

	//	for (Item e : repository.findAll()) {
	//		if (e.getQuantity() > 0)
				//all.add(e);
	//	}
	//	return all;
	//}
	@GetMapping("/items")
    public String showItems(Model model) {
        List<Item> availableCars = repository.findAll();
        model.addAttribute("cars", availableCars);
        return "items"; 
    }
	
	@PostMapping("/items")
	Item newItem(@RequestBody Item newItem) {
		return repository.save(newItem);
	}

	@GetMapping("/items/{id}")
	Item one(@PathVariable Long id) {
		return repository.findById(id).orElseThrow(() -> new ItemNotFoundException(id));
	}

	@PutMapping("/items/{id}")
	Item replaceItem(@RequestBody Item newItem, @PathVariable Long id,  @RequestParam int quantity) {

		
		return repository.findById(id).map(item -> {
			
			item.setBrand(newItem.getBrand());
			item.setColor(newItem.getColor());
			item.setCondition(newItem.getCondition());
			item.setMileage(newItem.getMileage());
			item.setPrice(newItem.getPrice());
			item.setQuantity(newItem.getQuantity()-newItem.getQuantity());
			item.setShape(newItem.getShape());
			item.setYear(newItem.getYear());
			return repository.save(item);
		}).orElseGet(() -> {
			return repository.save(newItem);
		});
		
	}

	@DeleteMapping("/items/{id}")
	void deleteItem(@PathVariable Long id) {
		repository.deleteById(id);
	}

}
